class PyWhoisException(Exception):
    pass
